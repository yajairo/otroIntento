package cl.ucn.felix.biblioteca.api;

public interface Libro {

	String getIsbn();
	String getTitulo();
	String getAutor();
	String getCategoria();
	
}
